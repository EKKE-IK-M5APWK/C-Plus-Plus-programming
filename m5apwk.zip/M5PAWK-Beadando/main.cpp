#include <iostream>
#include "Menu.hpp"
using namespace std;

int main()
{
    Menu m;
    m.execute();
    return 0;
}

